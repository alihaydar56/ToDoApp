const express=require("express");
const router=express();
const card=require('./card');

router.use('/card',card) //http://localhost:port/api/card



module.exports=router;
