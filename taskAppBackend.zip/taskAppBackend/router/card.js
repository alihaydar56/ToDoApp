const express=require("express");
const router=express();

const {getCarts,getCartItem,addCartItem, updateCartItem,deleteCartItem} =require('../controller/card'); // import methods from controller/card

router.get('',getCarts);
router.get('/get-item/:id',getCartItem);
router.post('/add-item',addCartItem);
router.put('/update-item/:id',updateCartItem);
router.delete('/delete-item/:id',deleteCartItem);

module.exports=router;