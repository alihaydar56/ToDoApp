# kanban-rast-mobile

Öncelikle bilgisiyarınızda bir terminal açıp; git clone https://github.com/alihaydar56/kanban-rast-mobile.git bu komutu çalıştırınız.
Bu çalıştırmış olduğunuz komut terminalde bulunduğunuz dizinime projeyi indirimiş olacaktır.
Projeyi visual studio code IDE ile açıp bir terminal açınız ve terminale şu nu yazınız; npm install 
eğer kütühanleri kurarken hata alırsanız projede kullanmış oldugum kütüphaneleri indiriniz,
npm install --legacy-peer-deps(bazı npm package ların sürümlerinden kaynaklı hata olabiliyor) yaparak çalıştırınız.
daha sonrasında terminale şu komut satırını yazınız; npm run dev
projede nodemon kullanılarak kullanıcının kodda yapmış oldugu herhangi bir değişiklikte termimali kapatıp açmasına gerek kalmadan değişiklikler etki edecektir.
eğer projeyi kendi database hesabınıza bağlamak isterseniz; config/config.env dosyasını açıp MONGO_URL e kendi database hesabınızı koyabilirsiniz.
