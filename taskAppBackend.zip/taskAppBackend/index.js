const express =require("express");
const app = express();
const dotenv = require("dotenv");
const router= require("./router/index");
const connectDatabase = require("./databaseConnection/database"); //import our mongodbConnection method

dotenv.config({ path: "./config/config.env" }); // to access enviroment variables.

connectDatabase(); // before running serve we will run our database connection

app.use(express.json()); // we use it for avoiding getting undefined data from req.body.

app.use("/api", router); // http://localhost:port/api

const PORT = process.env.PORT || 5000; // if it is undefined,port will be 5000

app.listen(PORT, (req, res) => {
  console.log("server is running");
});
