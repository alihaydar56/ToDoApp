const mongoose=require("mongoose");

const connectDatabase=(req,res)=>{
    mongoose.connect(process.env.MONGO_URI,{})
    .then(()=>{
        console.log("mongo connection is okey");
    })
    .catch((err)=>{
        console.log("mongo is not connected."+err.message)
    })
}

module.exports=connectDatabase;