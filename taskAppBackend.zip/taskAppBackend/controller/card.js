const cartSchema = require("../model/card");
/**
 * @param {*} boardId is belong to board that cart is created
 * @param {*} taskId is belong to task that cart is created
 * @param {*} req is for getting data from our requested service.
 * @param {*} res  is for return our method response.
 * @returns all item in our list
 */
const getCarts = async (req, res) => {
  try {
    const items = await cartSchema.find()
   
    .exec();

    if (items) {
      return res.json({success: true,message:'successfully get!',data: items});
    }
  } catch (error) {
    return res.json({success: false,error: error.message});
  }
};
/**
 ** @param {*} id is belong to card that wanted to get
 * @param {*} req is for getting data from our requested service.
 * @param {*} res  is for return our method response.
 * @returns given id if it is available
 */
const getCartItem = async (req, res) => {
  const { id } = req.params;
  try {
    const item = await cartSchema
    .findById({ _id: id })
    .populate('board')
    .populate('task')
    .populate('users')
    .exec();
    if (item) {
      return res.status(200).json({ success: true,message:'item is taken successfully!', data: item });
    }
  } catch (error) {
    return res.json({success: false,error: error.message});
  }
};

/**
  * @param {*} boardId is belong to board that cart is created
  * @param {*} taskId is belong to task that cart is created
  * @param {*} data is belong to cart to create
 */
const addCartItem = async (req, res) => {
  const {title,desc} = req.body;
  console.log(title,desc)
  try {
    let item = await cartSchema
    .create({title:title,description:desc,
      createdDate:new Date(),
      updatedDate:new Date()});
      if(item){
       
        return res.status(201).json({success: true,message:'item is created successfully!',data: item});
      }
    
  } catch (error) {
    return res.json({success: false,error: error.message});
  }
};

/**
 * this method take 2 parameter those are req and res
 * @param {*} req is for getting data from our requested service.
 * @param {*} res  is for return our method response.
 * @returns update cart item by given taskId.
 */
const updateCartItem = async (req, res) => {
  const {data} = req.body;
  const { id } = req.params;
  try {
    if(id){
      let item = await cartSchema
      .findByIdAndUpdate(
        { _id: id },
        {
          $set:{
           ...data,
            updatedDate: new Date(),
          }
        },{new:true}
      )
      .exec();
      console.log(item);
      if(item){
        return res.json({success: true,message:'item is updated successfully!',data: item});
      }
    }
  } catch (error) {
    return res.json({success: false,error: error.message});
  }
};

const deleteCartItem = async (req, res) => {
  const {id}=req.params;
  console.log(id);
  try {
    if(id){
      let item = await cartSchema
      .findByIdAndDelete(
        { _id: id },
        )
      .exec();
      if(item){
       
        return res.json({success: true,message:'item is deleted successfully'});
      }
    }
  } catch (error) {
    return res.json({success: false,error: error.message});
  }
};



module.exports = {
  getCarts,
  getCartItem,
  addCartItem,
  updateCartItem,
  deleteCartItem
};